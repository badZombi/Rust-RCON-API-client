Thank you for downloading Shards!

If you are looking for the SCSS files, make sure you
check out the official repository on GitHub:

https://github.com/designrevision/shards-ui
